#include <main_state.h>
#include <glad/glad.h>
#include <math.h>


#include <rafgl.h>

#include <game_constants.h>


static GLuint vao, vbo, shader_program_id, uni_M, uni_VP, uni_phase, uni_camera_pos, uni_tex_fun,uni_light_color,uni_light_direction;
static GLuint water_shader, water_uni_M, water_uni_VP, water_uni_phase, water_uni_camera_pos, water_uni_tex_fun, water_uni_light_color, water_uni_light_direction, water_uni_ambient;
static GLuint object_uni_light_colour, object_uni_light_direction, object_uni_camera_position, object_uni_object_colour;

static GLuint fake_water_shader, fake_water_uni_M, fake_water_uni_VP, fake_water_uni_phase, fake_water_uni_camera_pos, fake_water_uni_tex_fun, fake_water_uni_light_color, fake_water_uni_light_direction;
static rafgl_texture_t fake_water_normal_tex;
static rafgl_raster_t fake_water_normal_raster;

static rafgl_raster_t sand_normal_raster, sand_albedo_raster, pebbles_normal_raster, pebbles_albedo_raster, waterGrass_normal_raster, waterGrass_albedo_raster, heightmap_raster, water_normal_raster, water_distortion_raster;
static rafgl_texture_t sand_normal_tex, sand_albedo_tex, pebbles_normal_tex, pebbles_albedo_tex, waterGrass_normal_tex, waterGrass_albedo_tex, water_normal_tex, water_distortion_tex;

static GLuint skybox_shader, skybox_uni_V, skybox_uni_P, skybox_uni_skybox_sampler;
static rafgl_texture_t tex_skybox;
static rafgl_meshPUN_t mesh_cube;

static int screen_width, screen_height;

int flag=0;

rafgl_meshPUN_t plane1, water_plane;

rafgl_raster_t rasterRandom,rasterRandom2;
rafgl_texture_t heightmap_tex;

void terrain_tex_fun(GLuint prog_id)
{
    glUniform1i(glGetUniformLocation(prog_id, "heightmap"), 0);
    glUniform1i(glGetUniformLocation(prog_id, "albedo"), 1);
}

static vec3_t object_colour = RAFGL_BLUE;
static vec3_t light_colour = RAFGL_WHITE;
static vec3_t light_direction = vec3m(-0.55f, -0.55f, -0.63f);
static vec3_t ambient = RAFGL_GRAYX(0.16f);

void setupTex(GLuint tex_id){
    glBindTexture(GL_TEXTURE_2D, tex_id);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);

    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

    glGenerateMipmap(GL_TEXTURE_2D);

}

void main_state_init(GLFWwindow *window, void *args, int width, int height)
{
    //light_direction = v3_norm(vec3(-1, -1, -1));
    //light_colour = vec3(1.0f, 0.9f, 0.7f);


    rafgl_meshPUN_init(&plane1);
    rafgl_meshPUN_load_plane(&plane1,40, 40, 64, 64);

    rafgl_meshPUN_init(&water_plane);
    rafgl_meshPUN_load_plane(&water_plane,40, 40, 64, 64);


    rafgl_meshPUN_init(&mesh_cube);

    rafgl_meshPUN_load_cube(&mesh_cube, 1.0f);

    rafgl_texture_init(&tex_skybox);
    rafgl_texture_load_cubemap_named(&tex_skybox, "above_the_sea", "jpg");

    skybox_shader = rafgl_program_create_from_name("skybox_shader");
    skybox_uni_V = glGetUniformLocation(skybox_shader, "uni_V");
    skybox_uni_P = glGetUniformLocation(skybox_shader, "uni_P");
    skybox_uni_skybox_sampler = glGetUniformLocation(skybox_shader, "skybox_sampler");


    rafgl_raster_load_from_image(&sand_normal_raster, "res/images/Sand_1_Normal.png");
    rafgl_raster_load_from_image(&sand_albedo_raster, "res/images/Sand_1_Diffuse.png");

    rafgl_raster_load_from_image(&pebbles_normal_raster, "res/images/normal_pebbles.jpg");
    rafgl_raster_load_from_image(&pebbles_albedo_raster, "res/images/diffuse_pebbles.jpg");

    rafgl_raster_load_from_image(&waterGrass_normal_raster, "res/images/waterGrass_normal.jpg");
    rafgl_raster_load_from_image(&waterGrass_albedo_raster, "res/images/waterGrass_diffuse.jpg");

    rafgl_raster_load_from_image(&heightmap_raster, "res/images/height-map.png");

    /* rezervisemo texture slot.  */
    rafgl_texture_init(&sand_normal_tex);
    rafgl_texture_init(&sand_albedo_tex);
    rafgl_texture_init(&pebbles_normal_tex);
    rafgl_texture_init(&pebbles_albedo_tex);
    rafgl_texture_init(&waterGrass_normal_tex);
    rafgl_texture_init(&waterGrass_albedo_tex);
    rafgl_texture_init(&heightmap_tex);

    rafgl_texture_load_from_raster(&sand_normal_tex, &sand_normal_raster);
    rafgl_texture_load_from_raster(&sand_albedo_tex, &sand_albedo_raster);
    rafgl_texture_load_from_raster(&pebbles_normal_tex, &pebbles_normal_raster);
    rafgl_texture_load_from_raster(&pebbles_albedo_tex, &pebbles_albedo_raster);
    rafgl_texture_load_from_raster(&waterGrass_normal_tex, &waterGrass_normal_raster);
    rafgl_texture_load_from_raster(&waterGrass_albedo_tex, &waterGrass_albedo_raster);
    rafgl_texture_load_from_raster(&heightmap_tex, &heightmap_raster);

    setupTex(sand_albedo_tex.tex_id);
    setupTex(sand_normal_tex.tex_id);
    setupTex(pebbles_albedo_tex.tex_id);
    setupTex(pebbles_normal_tex.tex_id);
    setupTex(waterGrass_albedo_tex.tex_id);
    setupTex(waterGrass_normal_tex.tex_id);
    setupTex(heightmap_tex.tex_id);


    shader_program_id = rafgl_program_create_from_name("terrain_shader");
    uni_tex_fun = terrain_tex_fun;
    uni_M = glGetUniformLocation(shader_program_id, "uni_M");
    uni_VP = glGetUniformLocation(shader_program_id, "uni_VP");
    uni_phase = glGetUniformLocation(shader_program_id, "uni_phase");

    uni_camera_pos = glGetUniformLocation(shader_program_id, "uni_camera_pos");
    uni_light_color = glGetUniformLocation(shader_program_id, "uni_light_color");
    uni_light_direction = glGetUniformLocation(shader_program_id, "uni_light_direction");


    rafgl_raster_load_from_image(&water_normal_raster, "res/images/waterNormal.png");
    rafgl_texture_init(&water_normal_tex);
    rafgl_texture_load_from_raster(&water_normal_tex, &water_normal_raster);
    setupTex(water_normal_tex.tex_id);

    rafgl_raster_load_from_image(&water_distortion_raster, "res/images/waterDUDV.png");
    rafgl_texture_init(&water_distortion_tex);
    rafgl_texture_load_from_raster(&water_distortion_tex, &water_distortion_raster);
    setupTex(water_distortion_tex.tex_id);

    water_shader = rafgl_program_create_from_name("water_shader");
    water_uni_M = glGetUniformLocation(water_shader, "uni_M");
    water_uni_VP = glGetUniformLocation(water_shader, "uni_VP");
    water_uni_phase = glGetUniformLocation(water_shader, "uni_phase");
    water_uni_camera_pos = glGetUniformLocation(water_shader, "uni_camera_pos");
    water_uni_light_color = glGetUniformLocation(water_shader, "uni_light_color");
    water_uni_light_direction = glGetUniformLocation(water_shader, "uni_light_direction");
    water_uni_ambient = glGetUniformLocation(water_shader, "uni_ambient");


    rafgl_raster_load_from_image(&fake_water_normal_raster, "res/images/waterNormal.png");
    rafgl_texture_init(&fake_water_normal_tex);
    rafgl_texture_load_from_raster(&fake_water_normal_tex, &fake_water_normal_raster);
    setupTex(fake_water_normal_tex.tex_id);
    fake_water_shader = rafgl_program_create_from_name("fake_water_shader");
    fake_water_uni_M = glGetUniformLocation(fake_water_shader, "uni_M");
    fake_water_uni_VP = glGetUniformLocation(fake_water_shader, "uni_VP");
    fake_water_uni_phase = glGetUniformLocation(fake_water_shader, "uni_phase");
    fake_water_uni_camera_pos = glGetUniformLocation(fake_water_shader, "uni_camera_pos");




    glBindTexture(GL_TEXTURE_2D, 0);

}


mat4_t model, view, projection, view_projection;

/* field of view */
float fov = 75.0f;

vec3_t camera_position = vec3m(0.0f, 4.0f, 5.0f);
vec3_t camera_target = vec3m(0.0f, 0.0f, 0.0f);
vec3_t camera_up = vec3m(0.0f, 1.0f, 0.0f);
vec3_t aim_dir = vec3m(0.0f, 0.0f, -1.0f);

float camera_angle = -M_PIf * 0.5f;
float angle_speed = 0.2f * M_PIf;
float move_speed = 0.8f;

float hoffset = -0.35f * M_PIf;

void v3show(vec3_t v)
{
    printf("(%.2f %.2f %.2f)\n", v.x, v.y, v.z);
}

float time = 0.0f;
int reshow_cursor_flag = 0;
int last_lmb = 0;

void main_state_update(GLFWwindow *window, float delta_time, rafgl_game_data_t *game_data, void *args)
{
    screen_width = game_data->raster_width;
    screen_height = game_data->raster_height;

    time += delta_time;

    if(game_data->keys_down['A']) camera_angle -= angle_speed * delta_time;
    if(game_data->keys_down['D']) camera_angle += angle_speed * delta_time;


    if(game_data->is_lmb_down)
    {

        if(reshow_cursor_flag == 0)
            glfwSetInputMode(window, GLFW_CURSOR, GLFW_CURSOR_HIDDEN);

        float ydelta = game_data->mouse_pos_y - game_data->raster_height / 2;
        float xdelta = game_data->mouse_pos_x - game_data->raster_width / 2;

        if(!last_lmb)
        {
            ydelta = 0;
            xdelta = 0;
        }

        hoffset -= ydelta / game_data->raster_height;
        camera_angle += xdelta / game_data->raster_width;

        glfwSetCursorPos(window, game_data->raster_width / 2, game_data->raster_height / 2);
        reshow_cursor_flag = 1;
    }
    else if(reshow_cursor_flag)
    {
        reshow_cursor_flag = 0;
        glfwSetInputMode(window, GLFW_CURSOR, GLFW_CURSOR_NORMAL);
    }
    last_lmb = game_data->is_lmb_down;

    aim_dir = vec3(cosf(camera_angle), 0.0f, sinf(camera_angle));

    if(game_data->keys_down['W']) camera_position = v3_add(camera_position, v3_muls(aim_dir, move_speed * delta_time *10));
    if(game_data->keys_down['S']) camera_position = v3_add(camera_position, v3_muls(aim_dir, -move_speed * delta_time * 10));

    if(game_data->keys_down[RAFGL_KEY_SPACE]) camera_position.y += 1.0f * delta_time;
    if(game_data->keys_down[RAFGL_KEY_LEFT_SHIFT]) camera_position.y -= 1.0f * delta_time;


    float aspect = ((float)(game_data->raster_width)) / game_data->raster_height;
    projection = m4_perspective(fov, aspect, 0.1f, 100.0f);

    if(game_data->keys_pressed['Q']) flag = (flag+1)%2;


    if(!game_data->keys_down['T'])
    {
        view = m4_look_at(camera_position, v3_add(camera_position, v3_add(aim_dir, vec3(0.0f, hoffset, 0.0f))), camera_up);
    }
    else
    {
        view = m4_look_at(camera_position, vec3(0.0f, 0.0f, 0.0f), camera_up);
    }

    model = m4_identity();

    view_projection = m4_mul(projection, view);



}


void main_state_render(GLFWwindow *window, void *args)
{
    //glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    glBindFramebuffer(GL_FRAMEBUFFER, 0);
    glViewport(0, 0, screen_width, screen_height);

    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);


    glEnable(GL_DEPTH_TEST);
    glEnable(GL_CULL_FACE);
    glCullFace(GL_FRONT);

    glDepthMask(GL_FALSE);

    glUseProgram(skybox_shader);

    glBindVertexArray(mesh_cube.vao_id);
//    glEnableVertexAttribArray(0);
//    glEnableVertexAttribArray(1);
//    glEnableVertexAttribArray(2);

    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_CUBE_MAP, tex_skybox.tex_id);

    glUniform1i(skybox_uni_skybox_sampler, 0);

    glUniformMatrix4fv(skybox_uni_V, 1, GL_FALSE, view.m);
    glUniformMatrix4fv(skybox_uni_P, 1, GL_FALSE, projection.m);


    glDrawArrays(GL_TRIANGLES, 0, mesh_cube.vertex_count);

    glBindTexture(GL_TEXTURE_CUBE_MAP, 0);

    glUseProgram(shader_program_id);

//    glDisable(GL_DEPTH_TEST);
    glDepthMask(GL_TRUE);
    glDisable(GL_CULL_FACE);

    glBindVertexArray(vao);


    glEnable(GL_TEXTURE_2D);
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, sand_normal_tex.tex_id);
    glActiveTexture(GL_TEXTURE1);
    glBindTexture(GL_TEXTURE_2D, pebbles_normal_tex.tex_id);
    glActiveTexture(GL_TEXTURE2);
    glBindTexture(GL_TEXTURE_2D, waterGrass_normal_tex.tex_id);

    glActiveTexture(GL_TEXTURE3);
    glBindTexture(GL_TEXTURE_2D, sand_albedo_tex.tex_id);
    glActiveTexture(GL_TEXTURE4);
    glBindTexture(GL_TEXTURE_2D, pebbles_albedo_tex.tex_id);
    glActiveTexture(GL_TEXTURE5);
    glBindTexture(GL_TEXTURE_2D, waterGrass_albedo_tex.tex_id);
    glActiveTexture(GL_TEXTURE6);
    glBindTexture(GL_TEXTURE_2D, heightmap_tex.tex_id);

    glBindVertexArray(plane1.vao_id);


    glUniform3f(uni_light_color,light_colour.x,light_colour.y,light_colour.z);
    glUniform3f(uni_light_direction,light_direction.x,light_direction.y,light_direction.z);

    glUniform3f(uni_camera_pos, camera_position.x, camera_position.y, camera_position.z);


    glUniformMatrix4fv(uni_M, 1, GL_FALSE, (void*) model.m);
    glUniformMatrix4fv(uni_VP, 1, GL_FALSE, (void*) view_projection.m);
    glUniform1f(uni_phase,time * 0.1f);
    glUniform3f(uni_camera_pos, camera_position.x, camera_position.y, camera_position.z);
    glUniform1i(glGetUniformLocation(shader_program_id, "normal_map1"),0);
    glUniform1i(glGetUniformLocation(shader_program_id, "normal_map2"),1);
    glUniform1i(glGetUniformLocation(shader_program_id, "normal_map3"),2);
    glUniform1i(glGetUniformLocation(shader_program_id, "albedo_map1"),3);
    glUniform1i(glGetUniformLocation(shader_program_id, "albedo_map2"),4);
    glUniform1i(glGetUniformLocation(shader_program_id, "albedo_map3"),5);
    glUniform1i(glGetUniformLocation(shader_program_id, "heightmap"),6);

    //glUniform1f(glGetUniformLocation(shader_program_id, "time"),time );
    glDrawArrays(GL_TRIANGLES, 0, plane1.vertex_count);

    if(flag==0){
        glUseProgram(water_shader);

        glBindVertexArray(water_plane.vao_id);

        glActiveTexture(GL_TEXTURE0);
        glBindTexture(GL_TEXTURE_CUBE_MAP, tex_skybox.tex_id);
        glActiveTexture(GL_TEXTURE1);
        glBindTexture(GL_TEXTURE_2D, water_distortion_tex.tex_id);
        glActiveTexture(GL_TEXTURE2);
        glBindTexture(GL_TEXTURE_2D, water_normal_tex.tex_id);
        glActiveTexture(GL_TEXTURE3);
        glBindTexture(GL_TEXTURE_2D, waterGrass_albedo_tex.tex_id);

        glUniform3f(water_uni_camera_pos, camera_position.x, camera_position.y, camera_position.z);
        glUniformMatrix4fv(water_uni_M, 1, GL_FALSE, (void*) model.m);
        glUniformMatrix4fv(water_uni_VP, 1, GL_FALSE, (void*) view_projection.m);
        glUniform1i(glGetUniformLocation(water_shader, "skybox_tex"),0);
        glUniform1i(glGetUniformLocation(water_shader, "distortion_tex"),1);
        glUniform1i(glGetUniformLocation(water_shader, "normal_tex"),2);
        glUniform1i(glGetUniformLocation(water_shader, "waterGrass_tex"),3);

        glUniform1f(uni_phase,time);
        glUniform3f(water_uni_light_color,light_colour.x,light_colour.y,light_colour.z);
        glUniform3f(water_uni_light_direction,light_direction.x,light_direction.y,light_direction.z);
        glUniform3f(water_uni_ambient, ambient.x, ambient.y, ambient.z);
        glDrawArrays(GL_TRIANGLES, 0, water_plane.vertex_count);

    }
    else{
        glUseProgram(fake_water_shader);

		glBindVertexArray(water_plane.vao_id);

		glActiveTexture(GL_TEXTURE0);
        glBindTexture(GL_TEXTURE_2D, fake_water_normal_tex.tex_id);

		glUniform3f(fake_water_uni_camera_pos, camera_position.x, camera_position.y, camera_position.z);


		glUniformMatrix4fv(fake_water_uni_M, 1, GL_FALSE, (void*) model.m);
		glUniformMatrix4fv(fake_water_uni_VP, 1, GL_FALSE, (void*) view_projection.m);
		glUniform1f(fake_water_uni_phase,time * 0.1f);
		glUniform3f(fake_water_uni_camera_pos, camera_position.x, camera_position.y, camera_position.z);
        glUniform1i(glGetUniformLocation(fake_water_shader, "normal_map"),0);

		glDrawArrays(GL_TRIANGLES, 0, water_plane.vertex_count);

    }



//    glDisableVertexAttribArray(2);
//    glDisableVertexAttribArray(1);
//    glDisableVertexAttribArray(0);

    //glBindTexture(GL_TEXTURE_2D, 0);

    glBindVertexArray(0);

    glBindTexture(GL_TEXTURE_2D, 0);

}


void main_state_cleanup(GLFWwindow *window, void *args)
{
    /*
    glDeleteBuffers(1, &vbo);
    glDeleteVertexArrays(1, &vao);
    glDeleteShader(shader_program_id);
    */
}
