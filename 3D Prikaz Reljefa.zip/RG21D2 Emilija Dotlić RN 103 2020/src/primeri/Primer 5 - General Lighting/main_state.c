#include <main_state.h>
#include <glad/glad.h>
#include <math.h>


#include <rafgl.h>

#include <game_constants.h>


static rafgl_meshPUN_t meshes[6];

vec3_t object_colour = RAFGL_BLUE;
vec3_t light_colour = RAFGL_WHITE;
vec3_t light_direction = vec3m(-1.0f, -1.0f, -1.0f);
vec3_t ambient = RAFGL_GRAYX(0.16f);

static GLuint shaders[6], uni_M[6], uni_VP[6], uni_object_colour[6], uni_light_colour[6], uni_light_direction[6], uni_ambient[6], uni_camera_position[6];
static const char *shader_names[6] = {"v8PVD", "v8PVS", "v8PerVertex", "v8PPD", "v8PPS", "v8PerPixel"};
static const char *shader_title[6] = {"Per Vertex Diffuse", "Per Vertex Specular", "Per Vertex Combined", "Per Pixel Diffuse", "Per Pixel Specular", "Per Pixel Combined"};
static const char *mesh_names[6] = {"res/models/monkey.obj", "res/models/monkey-subdiv.obj", "res/models/suzanne.obj", "res/models/bunny.obj", "res/models/armadillo.obj", "res/models/dragon.obj"};

int current_shader = 0;

int num_meshes;


void main_state_init(GLFWwindow *window, void *args, int width, int height)
{
    num_meshes = sizeof(mesh_names) / sizeof(mesh_names[0]);
    object_colour = vec3(0.8f, 0.40f, 0.0f);

    rafgl_log_fps(RAFGL_TRUE);

    int i;

    for(i = 0; i < num_meshes; i++)
    {
        rafgl_log(RAFGL_INFO, "Loading mesh %d!\n", i + 1);
        rafgl_meshPUN_init(meshes + i);
        rafgl_meshPUN_load_from_OBJ(meshes + i, mesh_names[i]);
    }


    for(i = 0; i < 6; i++)
    {
        rafgl_log(RAFGL_INFO, "Compiling shader: %s\n", shader_names[i]);
        shaders[i] = rafgl_program_create_from_name(shader_names[i]);
        uni_M[i] = glGetUniformLocation(shaders[i], "uni_M");
        uni_VP[i] = glGetUniformLocation(shaders[i], "uni_VP");
        uni_object_colour[i] = glGetUniformLocation(shaders[i], "uni_object_colour");
        uni_light_colour[i] = glGetUniformLocation(shaders[i], "uni_light_colour");
        uni_light_direction[i] = glGetUniformLocation(shaders[i], "uni_light_direction");
        uni_ambient[i] = glGetUniformLocation(shaders[i], "uni_ambient");
        uni_camera_position[i] = glGetUniformLocation(shaders[i], "uni_camera_position");
    }


    glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
    glEnable(GL_DEPTH_TEST);

    light_direction = v3_norm(light_direction);

    //glEnable(GL_CULL_FACE);
    //glCullFace(GL_BACK);

    current_shader = 0;
    rafgl_window_set_title(shader_title[current_shader]);
}


mat4_t model, view, projection, view_projection;

/* field of view */
float fov = 75.0f;

vec3_t camera_position = vec3m(0.0f, 0.0f, 3.5f);
vec3_t camera_target = vec3m(0.0f, 0.0f, 0.0f);
vec3_t camera_up = vec3m(0.0f, 1.0f, 0.0f);
vec3_t aim_dir = vec3m(0.0f, 0.0f, -1.0f);

float camera_angle = -M_PIf * 0.5f;
float angle_speed = 0.2f * M_PIf;
float move_speed = 2.4f;

float hoffset = 0;

int rotate = 0;
float model_angle = 0.0f;

void v3show(vec3_t v)
{
    printf("(%.2f %.2f %.2f)\n", v.x, v.y, v.z);
}

float time = 0.0f;
int reshow_cursor_flag = 0;
int last_lmb = 0;


int selected_mesh = 0;

void main_state_update(GLFWwindow *window, float delta_time, rafgl_game_data_t *game_data, void *args)
{

    time += delta_time;
    model_angle += delta_time * rotate;


    if(game_data->is_lmb_down)
    {

        if(reshow_cursor_flag == 0)
        {
            glfwSetInputMode(window, GLFW_CURSOR, GLFW_CURSOR_HIDDEN);
        }

        float ydelta = game_data->mouse_pos_y - game_data->raster_height / 2;
        float xdelta = game_data->mouse_pos_x - game_data->raster_width / 2;

        if(!last_lmb)
        {
            ydelta = 0;
            xdelta = 0;
        }

        hoffset -= ydelta / game_data->raster_height;
        camera_angle += xdelta / game_data->raster_width;

        glfwSetCursorPos(window, game_data->raster_width / 2, game_data->raster_height / 2);
        reshow_cursor_flag = 1;
    }
    else if(reshow_cursor_flag)
    {
        reshow_cursor_flag = 0;
        glfwSetInputMode(window, GLFW_CURSOR, GLFW_CURSOR_NORMAL);
    }
    last_lmb = game_data->is_lmb_down;

    aim_dir = v3_norm(vec3(cosf(camera_angle), hoffset, sinf(camera_angle)));

    if(game_data->keys_down['W']) camera_position = v3_add(camera_position, v3_muls(aim_dir, move_speed * delta_time));
    if(game_data->keys_down['S']) camera_position = v3_add(camera_position, v3_muls(aim_dir, -move_speed * delta_time));

    vec3_t right = v3_cross(aim_dir, vec3(0.0f, 1.0f, 0.0f));
    if(game_data->keys_down['D']) camera_position = v3_add(camera_position, v3_muls(right, move_speed * delta_time));
    if(game_data->keys_down['A']) camera_position = v3_add(camera_position, v3_muls(right, -move_speed * delta_time));

    if(game_data->keys_pressed['R']) rotate = !rotate;

    if(game_data->keys_pressed[RAFGL_KEY_KP_ADD]) selected_mesh = (selected_mesh + 1) % num_meshes;
    if(game_data->keys_pressed[RAFGL_KEY_KP_SUBTRACT]) selected_mesh = (selected_mesh + num_meshes - 1) % num_meshes;

    if(game_data->keys_down[RAFGL_KEY_ESCAPE]) glfwSetWindowShouldClose(window, GLFW_TRUE);

    int i;
    for(i = 0; i < 6; i++)
    if(game_data->keys_down[RAFGL_KEY_1 + i] && current_shader != i)
    {
        current_shader = i;
        rafgl_window_set_title(shader_title[i]);
        break;
    }



    if(game_data->keys_down[RAFGL_KEY_SPACE]) camera_position.y += 1.0f * delta_time;
    if(game_data->keys_down[RAFGL_KEY_LEFT_SHIFT]) camera_position.y -= 1.0f * delta_time;


    float aspect = ((float)(game_data->raster_width)) / game_data->raster_height;    projection = m4_perspective(fov, aspect, 0.1f, 100.0f);

    if(!game_data->keys_down['T'])
    {
        view = m4_look_at(camera_position, v3_add(camera_position, aim_dir), camera_up);
    }
    else
    {
        view = m4_look_at(camera_position, vec3(0.0f, 0.0f, 0.0f), camera_up);
    }

    model = m4_identity();
    model = m4_rotation_y(model_angle);
    model = m4_mul(model, m4_translation(vec3(0.0f, sinf(model_angle) * 0.45, 0.0f)));

    view_projection = m4_mul(projection, view);



}


void main_state_render(GLFWwindow *window, void *args)
{
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    glUseProgram(shaders[current_shader]);

    glEnableVertexAttribArray(0);
    glEnableVertexAttribArray(1);
    glEnableVertexAttribArray(2);

    glBindVertexArray(meshes[selected_mesh].vao_id);

    glUniformMatrix4fv(uni_M[current_shader], 1, GL_FALSE, (void*) model.m);
    glUniformMatrix4fv(uni_VP[current_shader], 1, GL_FALSE, (void*) view_projection.m);

    glUniform3f(uni_object_colour[current_shader], object_colour.x, object_colour.y, object_colour.z);
    glUniform3f(uni_light_colour[current_shader], light_colour.x, light_colour.y, light_colour.z);
    glUniform3f(uni_light_direction[current_shader], light_direction.x, light_direction.y, light_direction.z);
    glUniform3f(uni_ambient[current_shader], ambient.x, ambient.y, ambient.z);
    glUniform3f(uni_camera_position[current_shader], camera_position.x, camera_position.y, camera_position.z);

    glDrawArrays(GL_TRIANGLES, 0, meshes[selected_mesh].vertex_count);

    glBindVertexArray(0);
    glDisableVertexAttribArray(2);
    glDisableVertexAttribArray(1);
    glDisableVertexAttribArray(0);

    glBindTexture(GL_TEXTURE_2D, 0);

}


void main_state_cleanup(GLFWwindow *window, void *args)
{

    int i;
    for(i = 0; i < 6; i++)
    {
        glDeleteShader(shaders[i]);
    }
}
