Za studente koji koriste linux/macOS
	Da bi ste kompajlirali i pokrenuli projekat, prvo instalirajte
	glfw bibljiteku (ili sudo apt-get install glfw ili brew install glfw)
	zatim se konzolom navedete do ovog direktorijuma i kucate komandu "make"